import { PutObjectCommand, S3Client } from '@aws-sdk/client-s3';
import { SQSClient } from '@aws-sdk/client-sqs';
import pkg from 'pg';

export const handler = async (event, context) => {

  const { Client } = pkg;

  const sqs = new SQSClient({
    region: process.env.AWS_REGION,
    credentials: {
      accessKeyId: process.env.AWS_ACCESS_KEY_ID,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    },
  });

  const s3 = new S3Client({
    region: process.env.AWS_REGION,
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      },
  });

  try {
    /**
     * Receives SQS message and extract object ID
     */
    const mensagem = event.Records[0].body;
    const { id } = JSON.parse(mensagem);
    
    const cliente = new Client({
      connectionString: process.env.DB_CONNECTION_STRING,
    });
    
    /**
     * Connect to PostgreSQL, get the object and saves at S3
     */
    await cliente.connect();
    
    const result = await cliente.query('SELECT * FROM jobs WHERE id = $1', [id]);

    const object = JSON.stringify(result.rows);
    
    const params = {
      Bucket: process.env.AWS_BUCKET, 
      Key: 'jobs.json',
      Body: object,
      ContentType: 'application/json',
    };

    const command = new PutObjectCommand(params)

    await s3.send(command);

    await cliente.end();

  } catch (error) {
    console.log('Lambda process error:', error);
  }
};
